from django.core.validators import MinValueValidator
from django.db import models
class Expense(models.Model):
    class Category(models.TextChoices):
        FOOD='FOOD','Food'; TRANSPORT='TRANSPORT','Transport'; UTILITIES='UTILITIES','Utilities'; ENTERTAINMENT='ENTERTAINMENT','Entertainment'; HEALTH='HEALTH','Health'; OTHER='OTHER','Other'
    title = models.CharField(max_length=150)
    amount = models.DecimalField(max_digits=10, decimal_places=2, validators=[MinValueValidator(0.01)])
    category = models.CharField(max_length=20, choices=Category.choices, default=Category.OTHER)
    date = models.DateField()
    notes = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    class Meta:
        ordering = ['-date','-created_at']
    def __str__(self): return f'{self.title} - {self.amount}'
