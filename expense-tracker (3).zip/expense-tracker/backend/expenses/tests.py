from datetime import date
from rest_framework.test import APITestCase
from .models import Expense
class ExpenseApiTests(APITestCase):
    def test_crud_and_summary(self):
        r = self.client.post('/api/expenses/', {'title':'Groceries','amount':'45.50','category':'FOOD','date':str(date.today())}, format='json'); self.assertEqual(r.status_code, 201)
        pk = r.data['id']; self.assertEqual(self.client.get('/api/expenses/').status_code, 200)
        self.assertEqual(self.client.get('/api/expenses/summary/').data['grand_total'], '45.50')
        self.assertEqual(self.client.patch(f'/api/expenses/{pk}/', {'amount':'50.00'}, format='json').status_code, 200)
        self.assertEqual(self.client.delete(f'/api/expenses/{pk}/').status_code, 204)
    def test_validation_and_404(self):
        self.assertEqual(self.client.post('/api/expenses/', {'amount':'-1','date':str(date.today())}, format='json').status_code, 400)
        self.assertEqual(self.client.get('/api/expenses/999/').status_code, 404)
