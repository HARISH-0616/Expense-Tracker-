from rest_framework import serializers
from .models import Expense
class ExpenseSerializer(serializers.ModelSerializer):
    category_label = serializers.CharField(source='get_category_display', read_only=True)
    class Meta:
        model = Expense
        fields = ['id','title','amount','category','category_label','date','notes','created_at','updated_at']
    def validate_title(self, value):
        if not value.strip(): raise serializers.ValidationError('Title is required.')
        return value.strip()
    def validate_amount(self, value):
        if value <= 0: raise serializers.ValidationError('Amount must be greater than zero.')
        return value
