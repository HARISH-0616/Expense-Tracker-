from django.db.models import Sum
from decimal import Decimal
from rest_framework import viewsets, status
from rest_framework.decorators import action
from rest_framework.response import Response
from .models import Expense
from .serializers import ExpenseSerializer
class ExpenseViewSet(viewsets.ModelViewSet):
    queryset = Expense.objects.all()
    serializer_class = ExpenseSerializer
    search_fields = ['title','notes','category']
    ordering_fields = ['date','amount','title','created_at']
    filterset_fields = ['category','date']
    @action(detail=False, methods=['get'])
    def summary(self, request):
        by_category = list(Expense.objects.values('category').annotate(total=Sum('amount')).order_by('-total'))
        labels = dict(Expense.Category.choices)
        grand_total = Expense.objects.aggregate(total=Sum('amount'))['total'] or Decimal('0.00')
        return Response({'grand_total': f'{grand_total:.2f}', 'by_category': [{'category': x['category'], 'label': labels.get(x['category'], x['category']), 'total': f"{x['total']:.2f}"} for x in by_category]})
