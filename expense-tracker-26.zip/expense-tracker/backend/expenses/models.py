from django.db import models
from django.core.validators import MinValueValidator


class Expense(models.Model):
    CATEGORY_CHOICES = [
        ("food", "Food"),
        ("transport", "Transport"),
        ("housing", "Housing"),
        ("utilities", "Utilities"),
        ("entertainment", "Entertainment"),
        ("health", "Health"),
        ("shopping", "Shopping"),
        ("other", "Other"),
    ]

    title = models.CharField(max_length=150)
    amount = models.DecimalField(
        max_digits=10, decimal_places=2, validators=[MinValueValidator(0.01)]
    )
    category = models.CharField(max_length=20, choices=CATEGORY_CHOICES, default="other")
    date = models.DateField()
    notes = models.TextField(blank=True, default="")
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ["-date", "-created_at"]

    def __str__(self):
        return f"{self.title} - {self.amount} ({self.category})"
