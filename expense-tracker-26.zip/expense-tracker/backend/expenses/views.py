from django.db.models import Sum
from rest_framework import viewsets, status
from rest_framework.decorators import action
from rest_framework.response import Response
from django_filters.rest_framework import DjangoFilterBackend
from rest_framework.filters import SearchFilter, OrderingFilter

from .models import Expense
from .serializers import ExpenseSerializer


class ExpenseViewSet(viewsets.ModelViewSet):
    """
    Provides full CRUD for expenses:
      GET    /api/expenses/          -> list (supports ?category=, ?search=, ?ordering=)
      POST   /api/expenses/          -> create
      GET    /api/expenses/{id}/     -> retrieve
      PUT    /api/expenses/{id}/     -> full update
      PATCH  /api/expenses/{id}/     -> partial update
      DELETE /api/expenses/{id}/     -> delete
      GET    /api/expenses/summary/  -> total + per-category breakdown
    """

    queryset = Expense.objects.all()
    serializer_class = ExpenseSerializer
    filter_backends = [DjangoFilterBackend, SearchFilter, OrderingFilter]
    filterset_fields = ["category", "date"]
    search_fields = ["title", "notes"]
    ordering_fields = ["date", "amount", "created_at"]

    @action(detail=False, methods=["get"])
    def summary(self, request):
        queryset = self.filter_queryset(self.get_queryset())
        total = queryset.aggregate(total=Sum("amount"))["total"] or 0
        by_category = (
            queryset.values("category")
            .annotate(total=Sum("amount"))
            .order_by("-total")
        )
        return Response(
            {
                "total": total,
                "by_category": list(by_category),
                "count": queryset.count(),
            },
            status=status.HTTP_200_OK,
        )
