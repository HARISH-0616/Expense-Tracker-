from datetime import date
from django.urls import reverse
from rest_framework.test import APITestCase
from rest_framework import status
from .models import Expense


class ExpenseCRUDTests(APITestCase):
    def setUp(self):
        self.expense = Expense.objects.create(
            title="Groceries",
            amount=45.50,
            category="food",
            date=date.today(),
        )
        self.list_url = "/api/expenses/"
        self.detail_url = f"/api/expenses/{self.expense.id}/"

    def test_create_expense_valid(self):
        payload = {
            "title": "Bus pass",
            "amount": "20.00",
            "category": "transport",
            "date": "2026-09-01",
        }
        response = self.client.post(self.list_url, payload)
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)
        self.assertEqual(Expense.objects.count(), 2)

    def test_create_expense_missing_title(self):
        payload = {"amount": "10.00", "category": "food", "date": "2026-09-01"}
        response = self.client.post(self.list_url, payload)
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)

    def test_create_expense_negative_amount(self):
        payload = {
            "title": "Bad expense",
            "amount": "-5.00",
            "category": "food",
            "date": "2026-09-01",
        }
        response = self.client.post(self.list_url, payload)
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)

    def test_list_expenses(self):
        response = self.client.get(self.list_url)
        self.assertEqual(response.status_code, status.HTTP_200_OK)

    def test_retrieve_expense(self):
        response = self.client.get(self.detail_url)
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data["title"], "Groceries")

    def test_retrieve_invalid_id(self):
        response = self.client.get("/api/expenses/9999/")
        self.assertEqual(response.status_code, status.HTTP_404_NOT_FOUND)

    def test_update_expense(self):
        payload = {
            "title": "Groceries (updated)",
            "amount": "50.00",
            "category": "food",
            "date": str(date.today()),
        }
        response = self.client.put(self.detail_url, payload)
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.expense.refresh_from_db()
        self.assertEqual(self.expense.title, "Groceries (updated)")

    def test_update_invalid_id(self):
        response = self.client.put("/api/expenses/9999/", {"title": "x"})
        self.assertEqual(response.status_code, status.HTTP_404_NOT_FOUND)

    def test_delete_expense(self):
        response = self.client.delete(self.detail_url)
        self.assertEqual(response.status_code, status.HTTP_204_NO_CONTENT)
        self.assertEqual(Expense.objects.count(), 0)

    def test_delete_invalid_id(self):
        response = self.client.delete("/api/expenses/9999/")
        self.assertEqual(response.status_code, status.HTTP_404_NOT_FOUND)

    def test_summary_endpoint(self):
        response = self.client.get("/api/expenses/summary/")
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertIn("total", response.data)
        self.assertIn("by_category", response.data)
