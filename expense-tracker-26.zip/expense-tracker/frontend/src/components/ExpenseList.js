import React from "react";

export default function ExpenseList({ expenses, onEdit, onDelete }) {
  if (!expenses.length) {
    return <p className="empty-state">No expenses recorded yet.</p>;
  }

  return (
    <table className="expense-table">
      <thead>
        <tr>
          <th>Date</th>
          <th>Title</th>
          <th>Category</th>
          <th>Amount</th>
          <th>Notes</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        {expenses.map((expense) => (
          <tr key={expense.id}>
            <td>{expense.date}</td>
            <td>{expense.title}</td>
            <td>
              <span className={`badge badge-${expense.category}`}>{expense.category}</span>
            </td>
            <td>${Number(expense.amount).toFixed(2)}</td>
            <td className="notes-cell">{expense.notes}</td>
            <td>
              <button onClick={() => onEdit(expense)}>Edit</button>
              <button className="danger" onClick={() => onDelete(expense.id)}>
                Delete
              </button>
            </td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}
