import React from "react";

export default function SummaryPanel({ summary }) {
  if (!summary) return null;

  return (
    <div className="summary-panel">
      <h3>Total spent: ${Number(summary.total).toFixed(2)}</h3>
      <div className="category-breakdown">
        {summary.by_category.map((c) => (
          <div key={c.category} className="category-row">
            <span className={`badge badge-${c.category}`}>{c.category}</span>
            <span>${Number(c.total).toFixed(2)}</span>
          </div>
        ))}
      </div>
    </div>
  );
}
