import React, { useEffect, useState } from "react";

const CATEGORIES = [
  "food",
  "transport",
  "housing",
  "utilities",
  "entertainment",
  "health",
  "shopping",
  "other",
];

const emptyForm = {
  title: "",
  amount: "",
  category: "other",
  date: new Date().toISOString().slice(0, 10),
  notes: "",
};

export default function ExpenseForm({ onSubmit, editingExpense, onCancelEdit }) {
  const [form, setForm] = useState(emptyForm);
  const [errors, setErrors] = useState({});

  useEffect(() => {
    if (editingExpense) {
      setForm({
        title: editingExpense.title,
        amount: editingExpense.amount,
        category: editingExpense.category,
        date: editingExpense.date,
        notes: editingExpense.notes || "",
      });
    } else {
      setForm(emptyForm);
    }
  }, [editingExpense]);

  const validate = () => {
    const newErrors = {};
    if (!form.title.trim()) newErrors.title = "Title is required.";
    if (!form.amount || Number(form.amount) <= 0)
      newErrors.amount = "Amount must be greater than zero.";
    if (!form.date) newErrors.date = "Date is required.";
    return newErrors;
  };

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const validationErrors = validate();
    setErrors(validationErrors);
    if (Object.keys(validationErrors).length > 0) return;

    try {
      await onSubmit({ ...form, amount: Number(form.amount).toFixed(2) });
      setForm(emptyForm);
      setErrors({});
    } catch (err) {
      const apiErrors = err?.response?.data;
      if (apiErrors && typeof apiErrors === "object") {
        setErrors(apiErrors);
      } else {
        setErrors({ non_field_errors: "Something went wrong. Please try again." });
      }
    }
  };

  return (
    <form className="expense-form" onSubmit={handleSubmit}>
      <h2>{editingExpense ? "Edit Expense" : "Add Expense"}</h2>

      <div className="form-row">
        <label>Title</label>
        <input
          type="text"
          name="title"
          value={form.title}
          onChange={handleChange}
          placeholder="e.g. Groceries"
        />
        {errors.title && <span className="error">{errors.title}</span>}
      </div>

      <div className="form-row">
        <label>Amount</label>
        <input
          type="number"
          step="0.01"
          min="0.01"
          name="amount"
          value={form.amount}
          onChange={handleChange}
          placeholder="0.00"
        />
        {errors.amount && <span className="error">{errors.amount}</span>}
      </div>

      <div className="form-row">
        <label>Category</label>
        <select name="category" value={form.category} onChange={handleChange}>
          {CATEGORIES.map((cat) => (
            <option key={cat} value={cat}>
              {cat.charAt(0).toUpperCase() + cat.slice(1)}
            </option>
          ))}
        </select>
      </div>

      <div className="form-row">
        <label>Date</label>
        <input type="date" name="date" value={form.date} onChange={handleChange} />
        {errors.date && <span className="error">{errors.date}</span>}
      </div>

      <div className="form-row">
        <label>Notes</label>
        <textarea
          name="notes"
          value={form.notes}
          onChange={handleChange}
          placeholder="Optional notes"
        />
      </div>

      {errors.non_field_errors && <div className="error">{errors.non_field_errors}</div>}

      <div className="form-actions">
        <button type="submit">{editingExpense ? "Update" : "Add"} Expense</button>
        {editingExpense && (
          <button type="button" className="secondary" onClick={onCancelEdit}>
            Cancel
          </button>
        )}
      </div>
    </form>
  );
}
