import axios from "axios";

const API_BASE_URL = process.env.REACT_APP_API_URL || "http://localhost:8000/api";

const client = axios.create({
  baseURL: API_BASE_URL,
  headers: { "Content-Type": "application/json" },
});

export const expenseApi = {
  list: (params = {}) => client.get("/expenses/", { params }),
  get: (id) => client.get(`/expenses/${id}/`),
  create: (data) => client.post("/expenses/", data),
  update: (id, data) => client.put(`/expenses/${id}/`, data),
  delete: (id) => client.delete(`/expenses/${id}/`),
  summary: (params = {}) => client.get("/expenses/summary/", { params }),
};

export default client;
