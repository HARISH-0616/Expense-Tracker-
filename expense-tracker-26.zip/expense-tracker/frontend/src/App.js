import React, { useCallback, useEffect, useState } from "react";
import { expenseApi } from "./api";
import ExpenseForm from "./components/ExpenseForm";
import ExpenseList from "./components/ExpenseList";
import SummaryPanel from "./components/SummaryPanel";
import "./App.css";

const CATEGORIES = [
  "all",
  "food",
  "transport",
  "housing",
  "utilities",
  "entertainment",
  "health",
  "shopping",
  "other",
];

export default function App() {
  const [expenses, setExpenses] = useState([]);
  const [summary, setSummary] = useState(null);
  const [editingExpense, setEditingExpense] = useState(null);
  const [categoryFilter, setCategoryFilter] = useState("all");
  const [search, setSearch] = useState("");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  const buildParams = useCallback(() => {
    const params = {};
    if (categoryFilter !== "all") params.category = categoryFilter;
    if (search.trim()) params.search = search.trim();
    return params;
  }, [categoryFilter, search]);

  const loadExpenses = useCallback(async () => {
    setLoading(true);
    setError("");
    try {
      const params = buildParams();
      const [listRes, summaryRes] = await Promise.all([
        expenseApi.list(params),
        expenseApi.summary(params),
      ]);
      const results = listRes.data.results ?? listRes.data;
      setExpenses(results);
      setSummary(summaryRes.data);
    } catch (err) {
      setError(
        "Could not reach the backend. Make sure the Django server is running on port 8000."
      );
    } finally {
      setLoading(false);
    }
  }, [buildParams]);

  useEffect(() => {
    loadExpenses();
  }, [loadExpenses]);

  const handleCreateOrUpdate = async (data) => {
    if (editingExpense) {
      await expenseApi.update(editingExpense.id, data);
      setEditingExpense(null);
    } else {
      await expenseApi.create(data);
    }
    await loadExpenses();
  };

  const handleDelete = async (id) => {
    if (!window.confirm("Delete this expense?")) return;
    await expenseApi.delete(id);
    await loadExpenses();
  };

  return (
    <div className="app-container">
      <header>
        <h1>💰 Expense Tracker</h1>
      </header>

      {error && <div className="alert-error">{error}</div>}

      <div className="main-grid">
        <aside>
          <ExpenseForm
            onSubmit={handleCreateOrUpdate}
            editingExpense={editingExpense}
            onCancelEdit={() => setEditingExpense(null)}
          />
          <SummaryPanel summary={summary} />
        </aside>

        <section>
          <div className="filters">
            <select value={categoryFilter} onChange={(e) => setCategoryFilter(e.target.value)}>
              {CATEGORIES.map((cat) => (
                <option key={cat} value={cat}>
                  {cat === "all" ? "All categories" : cat}
                </option>
              ))}
            </select>
            <input
              type="text"
              placeholder="Search title or notes..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>

          {loading ? <p>Loading...</p> : (
            <ExpenseList
              expenses={expenses}
              onEdit={setEditingExpense}
              onDelete={handleDelete}
            />
          )}
        </section>
      </div>
    </div>
  );
}
