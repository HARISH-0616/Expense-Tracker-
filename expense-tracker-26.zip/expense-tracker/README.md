# Expense Tracker (React + Django REST Framework)

A full-stack CRUD web application for tracking personal expenses, built per the
CRUD Web Application SOP (frontend + REST API + database + validation + tests).

## Tech Stack
- **Frontend:** React 18, Axios
- **Backend:** Django 5, Django REST Framework
- **Database:** SQLite (dev) — swap to PostgreSQL/MySQL for production
- **API testing:** Django `APITestCase` (Postman-compatible endpoints)

## Features
- Create, list, update, and delete expenses
- Categorize expenses (food, transport, housing, utilities, entertainment, health, shopping, other)
- Search by title/notes, filter by category, sort by date/amount
- Live summary: total spent + per-category breakdown
- Client-side and server-side validation
- CORS configured for local dev (React on :3000, Django on :8000)

## Project Structure
```
expense-tracker/
├── backend/
│   ├── expense_tracker/      # Django project settings/urls
│   ├── expenses/             # App: models, serializers, views, tests
│   ├── manage.py
│   └── requirements.txt
└── frontend/
    ├── public/index.html
    └── src/
        ├── api.js            # Axios client
        ├── App.js
        ├── App.css
        └── components/
            ├── ExpenseForm.js
            ├── ExpenseList.js
            └── SummaryPanel.js
```

## Setup — Backend
```bash
cd backend
python -m venv venv
source venv/bin/activate      # Windows: venv\Scripts\activate
pip install -r requirements.txt

python manage.py migrate
python manage.py createsuperuser   # optional, for /admin/
python manage.py runserver         # http://localhost:8000
```

## Setup — Frontend
```bash
cd frontend
npm install
npm start                          # http://localhost:3000
```

The frontend expects the API at `http://localhost:8000/api` by default.
Override with an `.env` file: `REACT_APP_API_URL=http://your-host/api`

## REST API Reference

| Operation  | Method | Endpoint                  | Notes                              |
|------------|--------|----------------------------|-------------------------------------|
| List       | GET    | `/api/expenses/`           | `?category=`, `?search=`, `?ordering=` |
| Retrieve   | GET    | `/api/expenses/{id}/`      |                                      |
| Create     | POST   | `/api/expenses/`           | body: title, amount, category, date, notes |
| Update     | PUT    | `/api/expenses/{id}/`      | full update                         |
| Partial    | PATCH  | `/api/expenses/{id}/`      | partial update                      |
| Delete     | DELETE | `/api/expenses/{id}/`      |                                      |
| Summary    | GET    | `/api/expenses/summary/`   | total + per-category totals         |

### Example: Create an expense
```bash
curl -X POST http://localhost:8000/api/expenses/ \
  -H "Content-Type: application/json" \
  -d '{"title":"Groceries","amount":"45.50","category":"food","date":"2026-09-17"}'
```

## Validation Rules
- `title`: required, non-empty
- `amount`: required, must be greater than 0
- `date`: required (ISO format `YYYY-MM-DD`)
- `category`: one of the predefined choices (defaults to `other`)

## Running Tests
```bash
cd backend
python manage.py test expenses
```
Covers: create (valid/missing/invalid), read (list/retrieve/invalid id),
update (valid/invalid id), delete (valid/invalid id), and the summary endpoint.

## Future Enhancements
- User authentication so each user only sees their own expenses
- Monthly/yearly charts (e.g. with Recharts)
- CSV export/import
- Recurring expense support
