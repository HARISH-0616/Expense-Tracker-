# Expense Tracker (React + Django REST Framework)

A full-stack CRUD Expense Tracker built per the SOP: React frontend, Django REST
Framework backend, SQLite database (swappable to PostgreSQL/MySQL), REST API,
validation, and tests.

## Architecture

```
User -> React (frontend) -> REST API (fetch) -> Django REST Framework (backend)
      -> Django ORM -> SQLite/PostgreSQL/MySQL Database
```

## Features
- Create, list, search, update, and delete expenses
- Categories (Food, Transport, Utilities, etc.)
- Summary endpoint: grand total + totals by category
- Client-side and server-side validation (required title, amount > 0, required date)
- CORS configured for local React dev server

## Project Structure
```
expense-tracker/
├── backend/                  # Django REST API
│   ├── expense_tracker/      # Project settings, urls, wsgi
│   ├── expenses/             # App: models, serializers, views, tests
│   ├── manage.py
│   └── requirements.txt
└── frontend/                 # React app
    ├── src/
    │   ├── components/       # ExpenseForm, ExpenseList, SummaryPanel
    │   ├── api.js            # fetch-based API client
    │   └── App.js
    └── package.json
```

## Backend Setup
```bash
cd backend
python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt
python manage.py migrate
python manage.py createsuperuser   # optional, for /admin
python manage.py runserver          # http://127.0.0.1:8000
```

## Frontend Setup
```bash
cd frontend
npm install
npm start                       # http://localhost:3000
```
By default the frontend calls `http://127.0.0.1:8000/api`. Override with a
`.env` file: `REACT_APP_API_URL=http://127.0.0.1:8000/api`.

## REST API Reference

| Operation | Method | Endpoint                  | Notes                          |
|-----------|--------|----------------------------|---------------------------------|
| Create    | POST   | `/api/expenses/`            | Body: title, amount, category, date, notes |
| Read all  | GET    | `/api/expenses/`            | Supports `?search=`, `?category=`, `?date=`, `?ordering=` |
| Read one  | GET    | `/api/expenses/{id}/`       |                                  |
| Update    | PUT/PATCH | `/api/expenses/{id}/`    |                                  |
| Delete    | DELETE | `/api/expenses/{id}/`       |                                  |
| Summary   | GET    | `/api/expenses/summary/`    | Grand total + totals by category |

### Example: create an expense
```bash
curl -X POST http://127.0.0.1:8000/api/expenses/ \
  -H "Content-Type: application/json" \
  -d '{"title":"Groceries","amount":"45.50","category":"FOOD","date":"2026-09-17"}'
```

## Validation Rules
- `title`: required, non-empty
- `amount`: required, must be > 0
- `date`: required
- `category`: one of the predefined choices (defaults to OTHER)
- Server-side validation always runs, even if the client-side check is bypassed

## Testing
Backend tests cover create/read/update/delete, invalid amount, missing title,
and 404s for non-existent records:
```bash
cd backend
python manage.py test
```
Recommended manual Postman checks:
1. Create with valid data → 201
2. Create with missing title → 400
3. Create with negative amount → 400
4. List with populated/empty DB → 200
5. Update valid vs. non-existent id → 200 vs. 404
6. Delete valid vs. non-existent id → 204 vs. 404

## Database Schema (Expense table)

| Field       | Type          | Constraints                     |
|-------------|---------------|----------------------------------|
| id          | BigAutoField  | Primary key                      |
| title       | CharField(150)| Required                         |
| amount      | Decimal(10,2) | Required, > 0                    |
| category    | CharField(20) | Choices, default OTHER           |
| date        | DateField     | Required                         |
| notes       | TextField     | Optional                         |
| created_at  | DateTime      | Auto-set on creation              |
| updated_at  | DateTime      | Auto-updated                      |

## Switching Database
Edit `backend/expense_tracker/settings.py` `DATABASES` block, e.g. for
PostgreSQL:
```python
DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.postgresql',
        'NAME': 'expense_tracker',
        'USER': os.environ.get('DB_USER'),
        'PASSWORD': os.environ.get('DB_PASSWORD'),
        'HOST': 'localhost',
        'PORT': '5432',
    }
}
```
Then `pip install psycopg2-binary` and re-run `migrate`.

## Future Enhancements
- User authentication (per-user expenses)
- Monthly/yearly charts
- CSV export
- Budget limits and alerts per category
