// Centralized API client for talking to the Django REST backend.
const API_BASE_URL = process.env.REACT_APP_API_URL || 'http://127.0.0.1:8000/api';

async function handleResponse(response) {
  if (response.status === 204) return null;
  const data = await response.json().catch(() => null);
  if (!response.ok) {
    const message = data ? JSON.stringify(data) : `Request failed with status ${response.status}`;
    throw new Error(message);
  }
  return data;
}

export const expenseApi = {
  // READ (list, with optional query params for filter/search/ordering)
  async list(params = {}) {
    const query = new URLSearchParams(params).toString();
    const response = await fetch(`${API_BASE_URL}/expenses/${query ? `?${query}` : ''}`);
    return handleResponse(response);
  },

  // READ (single)
  async get(id) {
    const response = await fetch(`${API_BASE_URL}/expenses/${id}/`);
    return handleResponse(response);
  },

  // CREATE
  async create(expense) {
    const response = await fetch(`${API_BASE_URL}/expenses/`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(expense),
    });
    return handleResponse(response);
  },

  // UPDATE
  async update(id, expense) {
    const response = await fetch(`${API_BASE_URL}/expenses/${id}/`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(expense),
    });
    return handleResponse(response);
  },

  // DELETE
  async remove(id) {
    const response = await fetch(`${API_BASE_URL}/expenses/${id}/`, {
      method: 'DELETE',
    });
    return handleResponse(response);
  },

  // Summary totals by category
  async summary(params = {}) {
    const query = new URLSearchParams(params).toString();
    const response = await fetch(`${API_BASE_URL}/expenses/summary/${query ? `?${query}` : ''}`);
    return handleResponse(response);
  },
};
