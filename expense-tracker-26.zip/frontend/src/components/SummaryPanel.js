import React from 'react';

export default function SummaryPanel({ summary }) {
  if (!summary) return null;

  return (
    <div className="summary-panel">
      <div className="summary-total">
        <span>Total Spent</span>
        <strong>${parseFloat(summary.grand_total || 0).toFixed(2)}</strong>
      </div>
      <div className="summary-by-category">
        {summary.by_category.map((row) => (
          <div key={row.category} className="summary-row">
            <span>{row.category}</span>
            <span>${parseFloat(row.total).toFixed(2)}</span>
          </div>
        ))}
      </div>
    </div>
  );
}
