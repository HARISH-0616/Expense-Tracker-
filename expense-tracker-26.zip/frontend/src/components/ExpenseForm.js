import React, { useState, useEffect } from 'react';

const CATEGORIES = [
  ['FOOD', 'Food & Dining'],
  ['TRANSPORT', 'Transport'],
  ['UTILITIES', 'Utilities'],
  ['ENTERTAINMENT', 'Entertainment'],
  ['HEALTH', 'Health & Fitness'],
  ['SHOPPING', 'Shopping'],
  ['EDUCATION', 'Education'],
  ['RENT', 'Rent & Housing'],
  ['OTHER', 'Other'],
];

const emptyForm = {
  title: '',
  amount: '',
  category: 'OTHER',
  date: new Date().toISOString().slice(0, 10),
  notes: '',
};

export default function ExpenseForm({ onSubmit, editingExpense, onCancelEdit }) {
  const [form, setForm] = useState(emptyForm);
  const [errors, setErrors] = useState({});

  useEffect(() => {
    if (editingExpense) {
      setForm({
        title: editingExpense.title,
        amount: editingExpense.amount,
        category: editingExpense.category,
        date: editingExpense.date,
        notes: editingExpense.notes || '',
      });
    } else {
      setForm(emptyForm);
    }
  }, [editingExpense]);

  function validate() {
    const errs = {};
    if (!form.title.trim()) errs.title = 'Title is required.';
    const amountNum = parseFloat(form.amount);
    if (!form.amount || isNaN(amountNum) || amountNum <= 0) {
      errs.amount = 'Enter an amount greater than 0.';
    }
    if (!form.date) errs.date = 'Date is required.';
    return errs;
  }

  function handleChange(e) {
    const { name, value } = e.target;
    setForm((prev) => ({ ...prev, [name]: value }));
  }

  async function handleSubmit(e) {
    e.preventDefault();
    const validationErrors = validate();
    setErrors(validationErrors);
    if (Object.keys(validationErrors).length > 0) return;

    const payload = { ...form, amount: parseFloat(form.amount).toFixed(2) };
    await onSubmit(payload, editingExpense ? editingExpense.id : null);
    if (!editingExpense) setForm(emptyForm);
  }

  return (
    <form className="expense-form" onSubmit={handleSubmit}>
      <h2>{editingExpense ? 'Edit Expense' : 'Add Expense'}</h2>

      <div className="field">
        <label htmlFor="title">Title</label>
        <input id="title" name="title" value={form.title} onChange={handleChange} placeholder="e.g. Groceries" />
        {errors.title && <span className="error">{errors.title}</span>}
      </div>

      <div className="field-row">
        <div className="field">
          <label htmlFor="amount">Amount</label>
          <input id="amount" name="amount" type="number" step="0.01" min="0.01"
                 value={form.amount} onChange={handleChange} placeholder="0.00" />
          {errors.amount && <span className="error">{errors.amount}</span>}
        </div>

        <div className="field">
          <label htmlFor="date">Date</label>
          <input id="date" name="date" type="date" value={form.date} onChange={handleChange} />
          {errors.date && <span className="error">{errors.date}</span>}
        </div>
      </div>

      <div className="field">
        <label htmlFor="category">Category</label>
        <select id="category" name="category" value={form.category} onChange={handleChange}>
          {CATEGORIES.map(([value, label]) => (
            <option key={value} value={value}>{label}</option>
          ))}
        </select>
      </div>

      <div className="field">
        <label htmlFor="notes">Notes (optional)</label>
        <textarea id="notes" name="notes" value={form.notes} onChange={handleChange} rows={2} />
      </div>

      <div className="form-actions">
        <button type="submit" className="btn btn-primary">
          {editingExpense ? 'Save Changes' : 'Add Expense'}
        </button>
        {editingExpense && (
          <button type="button" className="btn btn-secondary" onClick={onCancelEdit}>
            Cancel
          </button>
        )}
      </div>
    </form>
  );
}
