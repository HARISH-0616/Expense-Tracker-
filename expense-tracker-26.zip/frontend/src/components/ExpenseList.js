import React from 'react';

const CATEGORY_LABELS = {
  FOOD: 'Food & Dining',
  TRANSPORT: 'Transport',
  UTILITIES: 'Utilities',
  ENTERTAINMENT: 'Entertainment',
  HEALTH: 'Health & Fitness',
  SHOPPING: 'Shopping',
  EDUCATION: 'Education',
  RENT: 'Rent & Housing',
  OTHER: 'Other',
};

export default function ExpenseList({ expenses, loading, error, onEdit, onDelete }) {
  if (loading) return <p className="status-message">Loading expenses...</p>;
  if (error) return <p className="status-message error">Error: {error}</p>;
  if (!expenses.length) return <p className="status-message">No expenses yet. Add one above.</p>;

  return (
    <table className="expense-table">
      <thead>
        <tr>
          <th>Title</th>
          <th>Category</th>
          <th>Date</th>
          <th>Amount</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        {expenses.map((exp) => (
          <tr key={exp.id}>
            <td>{exp.title}</td>
            <td><span className="badge">{CATEGORY_LABELS[exp.category] || exp.category}</span></td>
            <td>{exp.date}</td>
            <td className="amount">${parseFloat(exp.amount).toFixed(2)}</td>
            <td className="actions">
              <button className="btn btn-small" onClick={() => onEdit(exp)}>Edit</button>
              <button className="btn btn-small btn-danger" onClick={() => onDelete(exp.id)}>Delete</button>
            </td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}
