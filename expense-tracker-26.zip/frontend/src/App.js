import React, { useState, useEffect, useCallback } from 'react';
import ExpenseForm from './components/ExpenseForm';
import ExpenseList from './components/ExpenseList';
import SummaryPanel from './components/SummaryPanel';
import { expenseApi } from './api';

export default function App() {
  const [expenses, setExpenses] = useState([]);
  const [summary, setSummary] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [editingExpense, setEditingExpense] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [notice, setNotice] = useState(null);

  const loadExpenses = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const params = searchTerm ? { search: searchTerm } : {};
      const [expenseData, summaryData] = await Promise.all([
        expenseApi.list(params),
        expenseApi.summary(params),
      ]);
      setExpenses(expenseData.results || expenseData);
      setSummary(summaryData);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }, [searchTerm]);

  useEffect(() => {
    loadExpenses();
  }, [loadExpenses]);

  function showNotice(message) {
    setNotice(message);
    setTimeout(() => setNotice(null), 3000);
  }

  async function handleSubmit(payload, id) {
    try {
      if (id) {
        await expenseApi.update(id, payload);
        showNotice('Expense updated.');
      } else {
        await expenseApi.create(payload);
        showNotice('Expense added.');
      }
      setEditingExpense(null);
      await loadExpenses();
    } catch (err) {
      showNotice(`Save failed: ${err.message}`);
    }
  }

  async function handleDelete(id) {
    if (!window.confirm('Delete this expense?')) return;
    try {
      await expenseApi.remove(id);
      showNotice('Expense deleted.');
      await loadExpenses();
    } catch (err) {
      showNotice(`Delete failed: ${err.message}`);
    }
  }

  return (
    <div className="app">
      <header className="app-header">
        <h1>💰 Expense Tracker</h1>
        <p>Track, categorize, and review your spending.</p>
      </header>

      {notice && <div className="notice">{notice}</div>}

      <div className="app-grid">
        <div className="app-column">
          <ExpenseForm
            onSubmit={handleSubmit}
            editingExpense={editingExpense}
            onCancelEdit={() => setEditingExpense(null)}
          />
          <SummaryPanel summary={summary} />
        </div>

        <div className="app-column app-column-wide">
          <div className="search-bar">
            <input
              type="text"
              placeholder="Search by title or notes..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          <ExpenseList
            expenses={expenses}
            loading={loading}
            error={error}
            onEdit={setEditingExpense}
            onDelete={handleDelete}
          />
        </div>
      </div>
    </div>
  );
}
