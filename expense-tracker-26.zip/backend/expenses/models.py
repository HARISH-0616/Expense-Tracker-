from django.core.validators import MinValueValidator
from django.db import models


class Expense(models.Model):
    """A single expense record."""

    CATEGORY_CHOICES = [
        ('FOOD', 'Food & Dining'),
        ('TRANSPORT', 'Transport'),
        ('UTILITIES', 'Utilities'),
        ('ENTERTAINMENT', 'Entertainment'),
        ('HEALTH', 'Health & Fitness'),
        ('SHOPPING', 'Shopping'),
        ('EDUCATION', 'Education'),
        ('RENT', 'Rent & Housing'),
        ('OTHER', 'Other'),
    ]

    title = models.CharField(max_length=150)
    amount = models.DecimalField(
        max_digits=10, decimal_places=2,
        validators=[MinValueValidator(0.01)]
    )
    category = models.CharField(max_length=20, choices=CATEGORY_CHOICES, default='OTHER')
    date = models.DateField()
    notes = models.TextField(blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['-date', '-created_at']

    def __str__(self):
        return f"{self.title} - {self.amount} ({self.category})"
