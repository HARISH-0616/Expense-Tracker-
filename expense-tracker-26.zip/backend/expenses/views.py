from django.db.models import Sum
from rest_framework import viewsets, filters, status
from rest_framework.decorators import action
from rest_framework.response import Response
from django_filters.rest_framework import DjangoFilterBackend

from .models import Expense
from .serializers import ExpenseSerializer


class ExpenseViewSet(viewsets.ModelViewSet):
    """
    Full CRUD for Expense records, plus a /summary/ endpoint
    that returns totals grouped by category.

    Supports:
      GET    /api/expenses/            -> list (filter/search/order)
      POST   /api/expenses/            -> create
      GET    /api/expenses/{id}/       -> retrieve
      PUT    /api/expenses/{id}/       -> full update
      PATCH  /api/expenses/{id}/       -> partial update
      DELETE /api/expenses/{id}/       -> delete
      GET    /api/expenses/summary/    -> totals by category + grand total
    """
    queryset = Expense.objects.all()
    serializer_class = ExpenseSerializer
    filter_backends = [DjangoFilterBackend, filters.SearchFilter, filters.OrderingFilter]
    filterset_fields = ['category', 'date']
    search_fields = ['title', 'notes']
    ordering_fields = ['date', 'amount', 'created_at']

    @action(detail=False, methods=['get'])
    def summary(self, request):
        qs = self.filter_queryset(self.get_queryset())
        by_category = (
            qs.values('category')
            .annotate(total=Sum('amount'))
            .order_by('-total')
        )
        grand_total = qs.aggregate(total=Sum('amount'))['total'] or 0
        return Response({
            'grand_total': grand_total,
            'by_category': list(by_category),
            'count': qs.count(),
        }, status=status.HTTP_200_OK)
