from decimal import Decimal
from django.urls import reverse
from rest_framework.test import APITestCase
from rest_framework import status
from .models import Expense


class ExpenseCRUDTests(APITestCase):
    def setUp(self):
        self.expense = Expense.objects.create(
            title="Groceries", amount=Decimal("45.50"),
            category="FOOD", date="2026-09-01"
        )
        self.list_url = reverse('expense-list')

    def test_list_expenses(self):
        response = self.client.get(self.list_url)
        self.assertEqual(response.status_code, status.HTTP_200_OK)

    def test_create_expense(self):
        payload = {
            "title": "Bus ticket", "amount": "2.50",
            "category": "TRANSPORT", "date": "2026-09-05"
        }
        response = self.client.post(self.list_url, payload)
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)
        self.assertEqual(Expense.objects.count(), 2)

    def test_create_expense_invalid_amount(self):
        payload = {
            "title": "Bad expense", "amount": "-5",
            "category": "OTHER", "date": "2026-09-05"
        }
        response = self.client.post(self.list_url, payload)
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)

    def test_create_expense_missing_title(self):
        payload = {"amount": "10.00", "category": "OTHER", "date": "2026-09-05"}
        response = self.client.post(self.list_url, payload)
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)

    def test_retrieve_expense(self):
        url = reverse('expense-detail', args=[self.expense.id])
        response = self.client.get(url)
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data['title'], "Groceries")

    def test_update_expense(self):
        url = reverse('expense-detail', args=[self.expense.id])
        response = self.client.patch(url, {"amount": "50.00"})
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.expense.refresh_from_db()
        self.assertEqual(self.expense.amount, Decimal("50.00"))

    def test_update_nonexistent_expense(self):
        url = reverse('expense-detail', args=[9999])
        response = self.client.patch(url, {"amount": "50.00"})
        self.assertEqual(response.status_code, status.HTTP_404_NOT_FOUND)

    def test_delete_expense(self):
        url = reverse('expense-detail', args=[self.expense.id])
        response = self.client.delete(url)
        self.assertEqual(response.status_code, status.HTTP_204_NO_CONTENT)
        self.assertEqual(Expense.objects.count(), 0)

    def test_delete_nonexistent_expense(self):
        url = reverse('expense-detail', args=[9999])
        response = self.client.delete(url)
        self.assertEqual(response.status_code, status.HTTP_404_NOT_FOUND)

    def test_summary_endpoint(self):
        url = reverse('expense-summary')
        response = self.client.get(url)
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertIn('grand_total', response.data)
