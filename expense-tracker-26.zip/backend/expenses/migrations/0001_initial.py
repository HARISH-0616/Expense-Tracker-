from django.db import migrations, models
import django.core.validators


class Migration(migrations.Migration):

    initial = True

    dependencies = []

    operations = [
        migrations.CreateModel(
            name='Expense',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('title', models.CharField(max_length=150)),
                ('amount', models.DecimalField(decimal_places=2, max_digits=10, validators=[django.core.validators.MinValueValidator(0.01)])),
                ('category', models.CharField(choices=[
                    ('FOOD', 'Food & Dining'),
                    ('TRANSPORT', 'Transport'),
                    ('UTILITIES', 'Utilities'),
                    ('ENTERTAINMENT', 'Entertainment'),
                    ('HEALTH', 'Health & Fitness'),
                    ('SHOPPING', 'Shopping'),
                    ('EDUCATION', 'Education'),
                    ('RENT', 'Rent & Housing'),
                    ('OTHER', 'Other'),
                ], default='OTHER', max_length=20)),
                ('date', models.DateField()),
                ('notes', models.TextField(blank=True, null=True)),
                ('created_at', models.DateTimeField(auto_now_add=True)),
                ('updated_at', models.DateTimeField(auto_now=True)),
            ],
            options={
                'ordering': ['-date', '-created_at'],
            },
        ),
    ]
